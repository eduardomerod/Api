<?php

namespace App\Controllers;
use CodeIgniter\Controller; // Asegúrate de incluir la clase Controller
class Home extends Controller
{
    protected $db;
    public function index()
    {
        $this->db = \Config\Database::connect();
        $query=$this->db->query('select plato_id, cantidad, numero, ubicacion, capacidad, 
        nombre, precio from pedidos, mesas, platos limit 10');
        // Obtener los resultados
        $result = $query->getResult();
        // Devuelve los resultados como JSON
        return $this->response->setJSON($result);
        
    }
}
